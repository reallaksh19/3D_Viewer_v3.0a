# Restore restraint symbols + stable nameplates

Apply from repo root:

```bash
git checkout main
git pull
git apply restore_restraints_nameplates.patch
node --check viewer/converters/inputxml-basic-glb/InputXmlBasicSceneBuilder.js
```

Changes:
- Restores restraint symbol proportions by reducing `RESTRAINT_VISUAL_SCALE` from 5 to 1.2 while keeping OD/2 and OD*2/3 contact logic unchanged.
- Changes node annotations from free-floating texture text to dark yellow-bordered nameplates.
- Changes ISONOTE annotations from free-floating magenta text to dark magenta-bordered nameplates.
- Updates converter metadata to `1.2.5-restored-restraints-nameplates`.
